<?php
session_start();
include 'config.php'; // Zorg ervoor dat je een correcte databaseverbinding hebt

// Haal alle merken uit de database
$merkenQuery = "SELECT DISTINCT merk FROM cars";
$merkenResult = mysqli_query($conn, $merkenQuery);

// Definieer de basis SQL-query voor het filteren van auto's
$query = "SELECT * FROM cars WHERE 1";

// Controleer of er filterwaarden zijn opgegeven en voeg ze toe aan de SQL-query
if (isset($_GET['merk']) && $_GET['merk'] != '') {
    $merk = $_GET['merk'];
    $query .= " AND merk = '$merk'";
}

if (isset($_GET['model']) && $_GET['model'] != '') {
    $model = $_GET['model'];
    $query .= " AND model LIKE '%$model%'";
}

if (isset($_GET['bouwjaar']) && $_GET['bouwjaar'] != '') {
    $bouwjaar = $_GET['bouwjaar'];
    $query .= " AND bouwjaar = $bouwjaar";
}

if (isset($_GET['min_prijs']) && $_GET['min_prijs'] != '') {
    $min_prijs = $_GET['min_prijs'];
    $query .= " AND prijs >= $min_prijs";
}

if (isset($_GET['max_prijs']) && $_GET['max_prijs'] != '') {
    $max_prijs = $_GET['max_prijs'];
    $query .= " AND prijs <= $max_prijs";
}

// Voer de query uit
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Occasions - PremiumWagens</title>
    <link rel="stylesheet" href="css/verkoop.css"> <!-- Verwijs naar je CSS-bestand -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar boven de banner -->
<nav class="navbar">
    <div class="container">
        <div class="logo">
            <a href="index.php">PremiumWagens</a>
        </div>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="occasions.php">Occasions</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
    </div>
</nav>

<!-- Banner van de indexpagina -->
<div class="banner">
    <h1>Welkom bij PremiumWagens</h1>
    <p>Bekijk onze prachtige occasions!</p>
</div>

<!-- Layout met filter aan de linkerkant en occasions rechts -->
<div class="main-content">
    <!-- Filter balk -->
    <div class="filter">
        <form action="occasions.php" method="GET">
            <div>
                <label for="merk">Merk:</label>
                <select name="merk" id="merk">
                    <option value="">Alle Merken</option>
                    <?php while ($row = mysqli_fetch_assoc($merkenResult)) : ?>
                        <option value="<?php echo $row['merk']; ?>"><?php echo $row['merk']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div>
                <label for="model">Model:</label>
                <input type="text" name="model" id="model" placeholder="Model">
            </div>

            <div>
                <label for="bouwjaar">Bouwjaar:</label>
                <input type="number" name="bouwjaar" id="bouwjaar" placeholder="Bouwjaar">
            </div>

            <div>
                <label for="min_prijs">Min. Prijs:</label>
                <input type="number" name="min_prijs" id="min_prijs" placeholder="Minimale Prijs">
            </div>

            <div>
                <label for="max_prijs">Max. Prijs:</label>
                <input type="number" name="max_prijs" id="max_prijs" placeholder="Maximale Prijs">
            </div>

            <button type="submit">Filteren</button>
        </form>
    </div>

    <!-- Grid met occasions -->
    <section class="occasions-grid">
        <?php while ($occasion = mysqli_fetch_assoc($result)) : ?>
        <div class="occasion-card">
            <img src="uploads/<?php echo $occasion['afbeelding']; ?>" alt="Afbeelding van <?php echo $occasion['merk']; ?>">
            <div class="occasion-info">
                <h3><?php echo $occasion['merk'] . " " . $occasion['model']; ?></h3>
                <p>Bouwjaar: <?php echo $occasion['bouwjaar']; ?></p>
                <p>Prijs: €<?php echo number_format($occasion['prijs'], 2, ',', '.'); ?></p>
                <!-- Link naar de auto-detailpagina -->
                <a href="auto_detail.php?id=<?php echo $occasion['id']; ?>">Meer Informatie</a>
            </div>
        </div>
        <?php endwhile; ?>
    </section>
</div>

</body>
</html>
