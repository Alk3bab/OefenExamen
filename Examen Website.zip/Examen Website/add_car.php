<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto Toevoegen - PremiumWagens</title>
    <link rel="stylesheet" href="css/admin.css"> <!-- Zorg dat het pad naar je CSS-bestand klopt -->
</head>

<?php
session_start();
include 'config.php'; // Verbind met de database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $merk = $_POST['merk'];
    $model = $_POST['model'];
    $bouwjaar = $_POST['bouwjaar'];
    $prijs = $_POST['prijs'];
    $beschrijving = $_POST['beschrijving'];

    // Verwerk de afbeelding
    $afbeelding = $_FILES['afbeelding']['name'];
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["afbeelding"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Controleer of het bestand een echte afbeelding is
    $check = getimagesize($_FILES["afbeelding"]["tmp_name"]);
    if ($check === false) {
        echo "Het bestand is geen afbeelding.";
        exit();
    }

    // Controleer het bestandstype (alleen bepaalde extensies toestaan)
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
    if (!in_array($imageFileType, $allowed_types)) {
        echo "Alleen JPG, JPEG, PNG en GIF bestanden zijn toegestaan.";
        exit();
    }

    // Controleer de bestandsgrootte (max 5MB)
    if ($_FILES["afbeelding"]["size"] > 5000000) {
        echo "Sorry, je bestand is te groot. Maximaal 5MB toegestaan.";
        exit();
    }

    // Verplaats het geüploade bestand naar de uploads-map
    if (move_uploaded_file($_FILES["afbeelding"]["tmp_name"], $target_file)) {
        // Voeg de auto toe aan de database
        $query = "INSERT INTO cars (merk, model, bouwjaar, prijs, afbeelding, beschrijving) 
                  VALUES ('$merk', '$model', '$bouwjaar', '$prijs', '$afbeelding', '$beschrijving')";
        
        if (mysqli_query($conn, $query)) {
            // Bevestigingsbericht met stijl en terugknop
            echo "
            <div class='success-message'>
                <h2>Auto succesvol toegevoegd!</h2>
                <p>De auto <strong>$merk $model</strong> is succesvol aan de database toegevoegd.</p>
                <a href='admin.php' class='btn-back'>Terug naar het Admin Panel</a>
            </div>
            ";
        } else {
            echo "Er is een fout opgetreden: " . mysqli_error($conn);
        }
    } else {
        echo "Fout bij het uploaden van de afbeelding.";
    }
}
?>